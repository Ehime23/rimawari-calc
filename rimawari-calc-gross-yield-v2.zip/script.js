
function calculate() {
  const price = parseFloat(document.getElementById('price').value);
  const income = parseFloat(document.getElementById('income').value);
  const result = document.getElementById('result');
  if (!price || !income) {
    result.innerText = "両方の値を入力してください。";
    return;
  }
  const yieldValue = (income / price) * 100;
  result.innerText = `表面利回りは ${yieldValue.toFixed(2)}% です。`;
}
